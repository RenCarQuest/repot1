@extends('user.layouts.master')
@section('content')
<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    Start Dashboard
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
            <div class="body-wrapper">
                <div class="table-area mt-10">
                    <div class="table-wrapper">
                        <div class="dashboard-header-wrapper">
                            <h4 class="title">{{ __("History List") }}</h4>
                        </div>
                        <div class="table-responsive">
                            <table class="custom-table">
                                <thead>
                                    <tr>
                                        <th>{{ __("Pick-up Location") }}</th>
                                        <th>{{ __("Destination") }}</th>
                                        <th>{{ __("Pick-up Date") }}</th>
                                        <th>{{ __("Pick-up Time") }}</th>
                                        <th>{{ __("Round Trip Date") }}</th>
                                        <th>{{ __("Round Trip Time") }}</th>
                                        <th>{{ __("Car Model") }}</th>
                                        <th>{{ __("Car Number") }}</th>
                                        <th>{{ __("Rate") }}</th>
                                        <th>{{ __("Status") }}</th>
                                    </tr>
                                </thead>
                                <tbody> @forelse($booking as $item)
                                    <tr>
                                        <td data-label="{{ __("Pick-up Location") }}">{{ $item->location }}</td>
                                        <td data-label="{{ __("Destination") }}">{{ $item->destination }}</td>
                                        <td data-label="{{ __("Pick-up Date") }}">{{ $item->pickup_date ? \Carbon\Carbon::parse($item->pickup_date)->format('d-m-Y') : '' }}
                                        </td>
                                        <td data-label="{{ __("Pick-up Time") }}">{{ $item->pickup_time ? \Carbon\Carbon::parse($item->pickup_time)->format('h:i A') : ''}}
                                        </td>
                                        <td data-label="{{ __("Round Trip Date") }}">{{ $item->round_pickup_date ? \Carbon\Carbon::parse($item->round_pickup_date)->format('d-m-Y') : 'N/A' }}
                                        </td>
                                        <td data-label="{{ __("Round Trip Time") }}">{{ $item->round_pickup_time ? \Carbon\Carbon::parse($item->round_pickup_time)->format('h:i A') : 'N/A'}}
                                        </td>
                                        <td data-label="{{ __("Car Model") }}">{{ $item->cars->car_model }}</td>
                                        <td data-label="{{ __("Car Number") }}">{{ $item->cars->car_number }}</td>
                                        <td data-label="{{ __("Rate") }}">{{ get_amount($item->cars->fees) }} {{ $default_currency->code }}</td>
                                        <td>   @if($item->status == 1) {{ __("Booked") }} @elseif ($item->status == 2) {{ __("OnGoing") }} @else {{ __("Completed") }} @endif</td>
                                     </tr>
                                    @empty
                                        @include('user.components.alerts.empty', ['colspan' => 10])
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>
                    {{ get_paginate($booking) }}
                </div>
            </div>
<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    End Dashboard
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
@endsection
